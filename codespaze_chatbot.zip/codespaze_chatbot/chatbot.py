import streamlit as st
from chatbot import chatbot_response

# Streamlit configuration
st.set_page_config(page_title="CodeSpaze Chatbot", layout="wide")

# App title and description
st.title("CodeSpaze Chatbot")
st.subheader("Welcome to CodeSpaze! Ask questions about internships, fresher jobs, or application processes. We'll assist you with formal and professional responses.")

# Initialize session state for queries and responses
if 'query_count' not in st.session_state:
    st.session_state['query_count'] = 1  # Start with one query input box
if 'queries' not in st.session_state:
    st.session_state['queries'] = []  # Track queries and responses

# Function to add a new query box
def add_query():
    st.session_state['query_count'] += 1  # Add another query box

# Display query input boxes and responses dynamically
for i in range(st.session_state['query_count']):
    # Input for each query with an 'Enter' triggering a new query box
    user_input = st.text_input(f"Type your question #{i + 1}:", key=f"query_{i}", on_change=add_query)

    # Display the chatbot response immediately below the query box
    if user_input:
        # Get the bot's response based on the user input
        response = chatbot_response(user_input)
        # Store the query and its corresponding response
        if len(st.session_state['queries']) <= i:
            st.session_state['queries'].append({"query": user_input, "response": response})
        else:
            st.session_state['queries'][i] = {"query": user_input, "response": response}
        
        # Display the chatbot's response immediately below the query box
        st.write(f"**Bot Response:** {response}")

# Sidebar with additional information about CodeSpaze
st.sidebar.title("About CodeSpaze Chatbot")
st.sidebar.info(
    """
    CodeSpaze Chatbot assists with:
    - Internships at CodeSpaze
    - Fresher job opportunities
    - Application processes
    - General inquiries
    
    Get instant answers to your questions and let us guide you through the process professionally. Powered by AI.
    """
)
