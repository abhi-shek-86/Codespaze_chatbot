import streamlit as st

# Function to generate responses based on user queries
def get_response(query):
    query = query.lower()
    if "internships" in query:
        return "At CodeSpaze, we offer internships in AI, Web Development, Full Stack Development, Machine Learning, and Android Development. Please let us know if you'd like more details!"
    elif "application process" in query:
        return "To apply for internships, please provide your name and contact information. We'll guide you through the process!"
    elif "fresher job opportunities" in query:
        return "Currently, we have openings for Frontend Developer and Process Associate roles. You can apply on the CodeSpaze website."
    elif "general inquiries" in query:
        return "For more details, please visit the CodeSpaze website or contact our support team."
    else:
        return "I'm sorry, I didn't understand that. Please ask about internships, application processes, fresher job opportunities, or general inquiries."

# Initialize the session state to keep track of the number of queries
if 'query_count' not in st.session_state:
    st.session_state['query_count'] = 1

# Function to handle adding a new query input
def add_query_box():
    st.session_state['query_count'] += 1

# Streamlit app layout
st.title("CodeSpaze Chatbot")

# Embed custom CSS for professional design
st.markdown("""
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .stButton button {
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            border-radius: 4px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .stButton button:hover {
            background-color: #45a049;
        }

        .stTextInput input {
            border-radius: 5px;
            padding: 10px;
            font-size: 14px;
            width: 100%;
            margin-bottom: 10px;
            border: 1px solid #ccc;
        }

        .stTextInput input:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .stWrite {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 15px;
            margin-top: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .stTitle {
            text-align: center;
            color: #333;
            font-size: 32px;
            margin-top: 30px;
        }

        .stSubheader {
            font-size: 18px;
            color: #555;
            margin-bottom: 20px;
        }

        .stMarkdown {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }

        .stInfo {
            background-color: #e3f2fd;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
        }

        .stSidebar {
            background-color: #f4f6f9;
            padding: 20px;
            border-radius: 8px;
        }

        .stSidebar .stTitle {
            font-size: 20px;
            color: #333;
        }

        .stSidebar .stMarkdown {
            font-size: 14px;
        }

        .stTextInput input {
            background-color: #fff;
        }
    </style>
""", unsafe_allow_html=True)

# Loop to create multiple input boxes based on the query count
for i in range(st.session_state['query_count']):
    user_input = st.text_input(f"Type your question #{i + 1}:", key=f"query_{i}", on_change=add_query_box)
    
    if user_input:
        response = get_response(user_input)
        st.write(f"**Response:** {response}")

# Displaying an informative message about how to interact with the bot
st.info("Type your question and press Enter. A new query box will appear for your next question.")

# Sidebar with additional information about CodeSpaze
st.sidebar.title("About CodeSpaze Chatbot")
st.sidebar.info(
    """
    CodeSpaze Chatbot assists with:
    - Internships at CodeSpaze
    - Fresher job opportunities
    - Application processes
    - General inquiries
    
    Get instant answers to your questions and let us guide you through the process professionally. Powered by AI.
    """
)
